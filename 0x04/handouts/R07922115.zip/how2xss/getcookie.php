<?php
echo "this is getcookie.php" . "<br>";
echo  $_GET['c'];


